const {MongoClient} = require("mongodb");
require('dotenv').config();

const URI = process.env.MONGO_URI;
const client = new MongoClient(URI);

async function InitialiseConnection(){
    await client.connect();
    console.log("connect to MongoDB");
}

module.exports = {client: client.db('fee-payments'), InitialiseConnection};