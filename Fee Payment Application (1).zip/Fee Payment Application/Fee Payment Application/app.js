const express = require("express")
const {InitialiseConnection} = require("./database")
const routes = require("./routes")
const PORT = process.env.PORT ||4000
const app = express();

app.use(express.json({limit: '50mb'}));

app.set("view engine","ejs");

app.use(express.static("public"));
app.use("/", routes);

InitialiseConnection();
app.listen(PORT,() =>{
    console.log("server is listening on port 8080");
});

