const express = require('express');
const controllers = require('../controllers');
const middlewares = require('../middlewares');

const router = express.Router();

router.post("/login", controllers.api.auth.login);
router.post("/fee", middlewares.checkRequired.bind(null, ['name', 'email', 'phone', 'amountPaid', 'due']), controllers.api.fee.create)

router.get("/admin/pages/about", controllers.api.admin.getAbout);
router.put("/admin/pages/about", middlewares.checkRequired.bind(null, ['content']), controllers.api.admin.updateAbout);

router.get("/admin/pages/help", controllers.api.admin.getHelpPage);
router.put("/admin/pages/help", middlewares.checkRequired.bind(null, ['content']), controllers.api.admin.updateHelpPage);

router.get("/admin/pages/fee-structure", controllers.api.admin.getFeeStructure);
router.put("/admin/pages/fee-structure", middlewares.checkRequired.bind(null, ['content']), controllers.api.admin.updateFeeStructure);

module.exports = router