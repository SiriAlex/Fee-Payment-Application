const express = require('express');
const apiRouter = require('./apiRoutes');
const pageRouter = require('./pageRoutes');

const router = express.Router();

router.use('/', pageRouter);
router.use('/api', apiRouter);


module.exports = router;