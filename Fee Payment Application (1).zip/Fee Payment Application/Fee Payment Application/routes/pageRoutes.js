const express = require('express');
const controllers = require('../controllers');
const router = express.Router();


router.get('/home', controllers.pages.home);
router.get('/contact', controllers.pages.contact);
router.get('/payments', controllers.pages.payments);
router.get('/fee', controllers.pages.fee);
router.get('/feepay', controllers.pages.feePay);
router.get('/help', controllers.pages.help);
router.get('/about', controllers.pages.about);
router.get('/admin', controllers.pages.admin);


module.exports = router;