$(window).on('load', initialize);

const tinymceOptions = {
  height: 400,
  width: '70%',
  menubar: false,
  branding: false,
  paste_data_images: false,
  automatic_uploads: false,
  responsive: true,
  placeholder: 'Please enter description of the screen',
  plugins: [
    'advlist', 'autolink', 'lists', 'link', 'charmap',
    'anchor', 'searchreplace', 'visualblocks', 'fullscreen',
    'insertdatetime', 'wordcount'
  ],
  toolbar: 'undo redo fullscreen | blocks | bold italic backcolor | ' +
    'alignleft aligncenter alignright alignjustify | ' +
    'bullist numlist outdent indent | removeformat'
}

function initialize() {
  $(`#description`).tinymce(tinymceOptions);

  $('body').on('click', '#aboutSMVP,#helpcenter,#feestructure', function() {
    const {pageId} = $(this).data();
    $('body').find('#createScreen').attr('data-active-page', pageId);

    $.ajax({
      url: '/api/admin/pages/' + pageId,
      success: function ({message, page}) {
        if (!page) {
          page = {};
        }
        tinyMCE.activeEditor.setContent(page.content || ' ');
      },
      error: function ({responseJSON, statusText}) {
        let errMessage = '';
        if (responseJSON && responseJSON.message) {
          errMessage = responseJSON.message;
        } else {
          errMessage = statusText;
        }

        Swal.fire(
            'Error!',
           errMessage,
            'error'
            );
        }
    })
    
  });

  $("body").on("click", "#createScreen", function (event) {
    event.preventDefault();
    const {activePage} = $(this).data();
    const content = tinyMCE.activeEditor.getContent();
    if (!content || !content.length) {
      return Swal.fire(
        'Error!',
        'Please enter content first before saving.',
        'error'
        )
    }

    $.ajax({
      url: '/api/admin/pages/' + activePage,
      method: 'put',
      data: JSON.stringify({content}),
      contentType: 'application/json; charset=utf-8',
      dataType: 'json',
      success: function ({message}) {
        Swal.fire(
          'Success!',
          message || 'Data was saved successfully',
          'success'
          ).then(() => location.reload());
      },
      error: function ({responseJSON, statusText}) {
        let errMessage = '';
        if (responseJSON && responseJSON.message) {
          errMessage = responseJSON.message;
        } else {
          errMessage = statusText;
        }

        Swal.fire(
            'Error!',
            errMessage,
            'error'
            );
    }
    })

  });
}