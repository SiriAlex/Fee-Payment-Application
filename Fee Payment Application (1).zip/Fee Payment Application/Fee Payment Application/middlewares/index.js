const middlewares = module.exports;

middlewares.checkRequired = (fields=[], req, res, next) => {
    if (!fields) next();
    if (!Array.isArray(fields)) {
        return res.status(400).json({
            message: 'fields must be an array, found ' + typeof fields
        })
    }

    const requestBody = req.body;
    const missingFields = [];

    fields.forEach(field => {
        if (!requestBody.hasOwnProperty(field) || !requestBody[field]) {
            missingFields.push(field);
        }
    });

    if (missingFields.length) {
        return res.status(400).json({
            message: 'Required fields are missing from the API call: ' + missingFields.join(', ')
        })
    }

    next();
}