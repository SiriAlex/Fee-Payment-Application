const {client} = require('../../database')
const config = require('./config');

const pageControllers = module.exports;

pageControllers.home = async function (req, res) {
    res.render('home');
}

pageControllers.contact = async function (req, res) {
    res.render('contact');
}

pageControllers.payments = async function (req, res) {
    const collectionName = 'fees';
    const paymentsData = await client.collection(collectionName).find().toArray();

    const pageData = {
        title: 'Fees', 
        data: paymentsData
    };

    res.render('payments', pageData);
}

pageControllers.about= async function (req, res) {
    const data = await client.collection('admin_pages').findOne({type: 'admin:about'});
    const pageData = {
        description: data
    }
    res.render('about', pageData);
}

pageControllers.fee = async function (req, res) {
    const data = await client.collection('admin_pages').findOne({type: 'admin:fee:structure'});
    const pageData = {
        description: data
    }
    res.render('fee', pageData);
}

pageControllers.feePay = async function (req, res) {
    res.render('feepay');
}

pageControllers.help= async function (req, res) {
    const data = await client.collection('admin_pages').findOne({type: 'admin:help'});
    const pageData = {
        description: data
    }
    res.render('help', pageData);
}

pageControllers.admin= async function (req, res) {
    const data = await client.collection('admin_pages').findOne({type: 'admin:fee:structure'});
    const pageData = {
        feeStructure: data
    }
    res.render('admin', pageData);
}
    