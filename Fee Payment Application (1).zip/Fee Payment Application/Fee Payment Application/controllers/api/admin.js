const {client} = require('../../database');
const collectionName = 'admin_pages';

const adminApi = module.exports;

adminApi.getAbout = async (req, res) => {
    const key = 'admin:about';

    const pageData = await client.collection(collectionName).findOne({type: key});
    res.status(200).json({message: 'Content fetched successfully!', page: pageData});
}

adminApi.updateAbout = async (req, res) => {
    const {content} = req.body;
    const key = 'admin:about';

    const contentPayload = {
        content: content.trim(),
        updatedAt: new Date().toISOString(),
        type: key
    }

    await client.collection(collectionName).updateOne({type: key}, {$set: contentPayload}, {upsert: true});
    res.status(200).json({message: 'Content was update successfully!'});
}





adminApi.getFeeStructure = async (req, res) => {
    const key = 'admin:fee:structure';

    const pageData = await client.collection(collectionName).findOne({type: key});
    res.status(200).json({message: 'Content fetched successfully!', page: pageData});
}

adminApi.updateFeeStructure = async (req, res) => {
    const {content} = req.body;
    const key = 'admin:fee:structure';

    const contentPayload = {
        content: content.trim(),
        updatedAt: new Date().toISOString(),
        type: key
    }

    await client.collection(collectionName).updateOne({type: key}, {$set: contentPayload}, {upsert: true});
    res.status(200).json({message: 'Content was update successfully!'});
}





adminApi.getHelpPage = async (req, res) => {
    const key = 'admin:help';

    const pageData = await client.collection(collectionName).findOne({type: key});
    res.status(200).json({message: 'Content fetched successfully!', page: pageData});
}

adminApi.updateHelpPage = async (req, res) => {
    const {content} = req.body;
    const key = 'admin:help';

    const contentPayload = {
        content: content.trim(),
        updatedAt: new Date().toISOString(),
        type: key
    }

    await client.collection(collectionName).updateOne({type: key}, {$set: contentPayload}, {upsert: true});
    res.status(200).json({message: 'Content was update successfully!'});
}