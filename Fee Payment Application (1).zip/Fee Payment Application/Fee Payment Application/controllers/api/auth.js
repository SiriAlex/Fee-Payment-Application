const controller = {};

const loginTemplate = "login";

controller.login = async (req, res) => {
    // const { email, password } = req.body
    // await compileTpl(loginTemplate)
    // if (!email || !password) {
    //     res.render(loginTemplate,"email and password are required")
    // }
    // try {
    //     const userValid = dbUser.findOne({ email: email })
    //     if (!userValid) { res.render(loginTemplate,"user not found") }
    //     else {
    //         let isMatch = false
    //         if (password === uservalid.password)
    //             isMatch = true
    //     }
    //     if (!isMatch ){
    //         res.render(loginTemplate,"password is not matched")
    //     }
    //     res.redirect("/post")

    // } catch (error) {
    //     res.send(error.message)
    // }
}
   

controller.createPost = async function (req, res) {
    const posttemplate = "pa";
    try {
        const { imageURL, name, location, description } = req.body
        const newPost = { imageURL, name, location, description }
        const post = db.insertOne(newPost)
        res.send("post created successfully")
    } catch (error) {
        res.send(error.message);
    }
}

module.exports = controller;