const {client} = require('../../database')

const feeApi = module.exports;
const collectionName = 'fees';

feeApi.create = async function (req, res) {
    const {
        name, email, phone, amountPaid, due
    } = req.body;

    const feePayload = {
        name, email, phone, 
        amountPaid: Number(amountPaid),
        due: Number(due)
    };

    const ack = await client.collection(collectionName).insertOne(feePayload);
    res.status(200).json({
        message: 'Created sucessfully!',
        fee: ack
    })
}