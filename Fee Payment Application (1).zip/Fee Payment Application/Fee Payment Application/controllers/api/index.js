const apiControllers= module.exports;

apiControllers.auth = require('./auth');
apiControllers.fee = require('./fee');
apiControllers.admin = require('./admin');